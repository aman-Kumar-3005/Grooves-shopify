<?php
/**
 * Grooves Customer Care Backend Configuration
 *
 * Configured with live Shopify Partner App credentials.
 * Only update the Hostinger MySQL Database settings below.
 */

declare(strict_types=1);

return [
    // --------------------------------------------------------------------------
    // Environment
    // --------------------------------------------------------------------------
    'APP_ENV' => 'production',

    // --------------------------------------------------------------------------
    // Hostinger MySQL Database Credentials
    // --------------------------------------------------------------------------
    // Obtain these from Hostinger hPanel -> Databases -> Management
    'DB_HOST' => 'localhost',
    'DB_PORT' => 3306,
    'DB_NAME' => 'u123456789_grooves',          // Replace with your Hostinger database name (e.g. u123456789_grooves)
    'DB_USER' => 'u123456789_grooves_user',     // Replace with your Hostinger database user
    'DB_PASS' => 'your_strong_db_password_here', // Replace with your database password
    'DB_CHARSET' => 'utf8mb4',

    // --------------------------------------------------------------------------
    // Shopify Partner App Credentials (2026 OAuth Client Credentials Flow)
    // --------------------------------------------------------------------------
    // Permanent myshopify domain
    'SHOPIFY_STORE_DOMAIN' => '1tsavh-dz.myshopify.com',

    // Shopify Partner App Client ID
    'SHOPIFY_CLIENT_ID' => '6570ff9a4fb0d23dbc3175c63e7d6687',

    // Shopify Partner App Client Secret (Token exchange & Proxy HMAC verification)
    'SHOPIFY_CLIENT_SECRET' => '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',

    // Shopify Admin API Version
    'SHOPIFY_API_VERSION' => '2026-10',

    // Legacy static access token fallback (not needed when using Client ID)
    'SHOPIFY_ADMIN_ACCESS_TOKEN' => '',

    // --------------------------------------------------------------------------
    // Staff Console Security
    // --------------------------------------------------------------------------
    // Key used to unlock the private staff portal at /staff/
    'SUPPORT_ADMIN_KEY' => 'AmanGroovesAdmin_2026!@#',

    // --------------------------------------------------------------------------
    // Default Warranty & Return Policies
    // --------------------------------------------------------------------------
    'DEFAULT_WARRANTY_DAYS' => 365,
    'DEFAULT_RETURN_WINDOW_DAYS' => 7,
    'DEFAULT_RETURN_WINDOW_BASIS' => 'delivery', // 'delivery' or 'purchase'

    // --------------------------------------------------------------------------
    // Abuse Protection & Rate Limiting
    // --------------------------------------------------------------------------
    'MAX_LOOKUPS_PER_WINDOW' => 20,
    'RATE_WINDOW_MINUTES' => 15,

    // --------------------------------------------------------------------------
    // Attachments Configuration
    // --------------------------------------------------------------------------
    'UPLOAD_DIR' => __DIR__ . '/uploads',
    'MAX_FILE_SIZE' => 10 * 1024 * 1024, // 10 MB
    'MAX_FILES_COUNT' => 5,
    'ALLOWED_MIME_TYPES' => [
        'image/jpeg' => '.jpg',
        'image/png'  => '.png',
        'image/webp' => '.webp',
        'application/pdf' => '.pdf',
    ],
];
